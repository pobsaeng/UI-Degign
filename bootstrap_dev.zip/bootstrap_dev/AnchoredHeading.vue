    var AnchoredHeading = Vue.component('AnchoredHeading', {
        data: function () {
            return {
                users: []
            }
        },
        created() {
            var vm = this
            this.$http.get('https://jsonplaceholder.typicode.com/users')
                .then(function (response) {
                    vm.users = response.data
                })
        },
        template: `
            <div>
                <div v-for="user in users">
                    {{user}}
                </div>
            </div>
            `
    });
export default AnchoredHeading;
